from graphbrain import *


def run(args):
    print('creating hypergraph...')
    hgraph(args.hg)
    print('done.')
